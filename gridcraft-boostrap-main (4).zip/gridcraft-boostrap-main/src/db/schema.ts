
// This file defines the database schema for our application
// In a real application, this would be used with Supabase or PostgreSQL directly

// Users table
export interface User {
  id: string;
  created_at: string;
  email: string;
  first_name: string;
  last_name: string;
  avatar_url: string | null;
  organization_id: string;
  role: 'admin' | 'manager' | 'user';
}

// Organizations table
export interface Organization {
  id: string;
  created_at: string;
  name: string;
  logo_url: string | null;
}

// Locations table
export interface Location {
  id: string;
  created_at: string;
  name: string;
  organization_id: string;
  address: string;
  city: string;
  state: string;
  zip: string;
}

// Appointments table
export interface Appointment {
  id: string;
  created_at: string;
  patient_id: string;
  provider_id: string;
  location_id: string;
  date: string;
  status: 'scheduled' | 'verified' | 'failed' | 'cancelled';
  verification_date: string | null;
}

// Patients table
export interface Patient {
  id: string;
  created_at: string;
  first_name: string;
  last_name: string;
  date_of_birth: string;
  gender: string;
  email: string | null;
  phone: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  zip: string | null;
}

// Insurance Policies table
export interface InsurancePolicy {
  id: string;
  created_at: string;
  patient_id: string;
  insurance_provider: string;
  policy_number: string;
  group_number: string | null;
  is_primary: boolean;
  expiration_date: string | null;
}

// Claims table
export interface Claim {
  id: string;
  created_at: string;
  patient_id: string;
  appointment_id: string;
  insurance_policy_id: string;
  status: 'ready' | 'in_progress' | 'sent' | 'rejected' | 'denied' | 'paid';
  amount: number;
  submitted_date: string | null;
  paid_date: string | null;
  rejected_date: string | null;
  denial_date: string | null;
  resolution_date: string | null;
  resolution_note: string | null;
}

// Payments table
export interface Payment {
  id: string;
  created_at: string;
  claim_id: string;
  amount: number;
  payment_date: string;
  eob_status: 'downloaded' | 'processed' | 'posted' | 'pending';
  eob_download_date: string | null;
  eob_process_date: string | null;
  eob_posting_date: string | null;
}
