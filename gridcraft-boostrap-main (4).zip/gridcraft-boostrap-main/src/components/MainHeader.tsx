
import React, { useState } from "react";
import { Bell, HelpCircle, ChevronDown } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export const MainHeader = () => {
  const [notificationCount, setNotificationCount] = useState(3);
  
  return (
    <div className="flex items-center justify-end gap-4 p-4 bg-white">
      {/* Notification Dropdown */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon" className="relative">
            <Bell size={20} />
            {notificationCount > 0 && (
              <Badge 
                className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs bg-red-500 text-white"
              >
                {notificationCount}
              </Badge>
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-80">
          <div className="flex justify-between items-center p-4 border-b">
            <h4 className="font-medium">Notifications</h4>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setNotificationCount(0)}
            >
              Mark all as read
            </Button>
          </div>
          <div className="max-h-96 overflow-auto">
            <DropdownMenuItem className="p-4 cursor-pointer">
              <div>
                <div className="font-medium">Eligibility verification needed</div>
                <div className="text-sm text-gray-500 mt-1">3 patients require eligibility verification</div>
                <div className="text-xs text-gray-400 mt-1">10 minutes ago</div>
              </div>
            </DropdownMenuItem>
            <DropdownMenuItem className="p-4 cursor-pointer">
              <div>
                <div className="font-medium">Claim rejection alert</div>
                <div className="text-sm text-gray-500 mt-1">Claim #C10045 was rejected</div>
                <div className="text-xs text-gray-400 mt-1">1 hour ago</div>
              </div>
            </DropdownMenuItem>
            <DropdownMenuItem className="p-4 cursor-pointer">
              <div>
                <div className="font-medium">Payment posted</div>
                <div className="text-sm text-gray-500 mt-1">Payment for claim #C10042 has been posted</div>
                <div className="text-xs text-gray-400 mt-1">3 hours ago</div>
              </div>
            </DropdownMenuItem>
          </div>
          <div className="p-2 border-t text-center">
            <Button variant="ghost" size="sm" className="w-full">View all notifications</Button>
          </div>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Support Dropdown */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon">
            <HelpCircle size={20} />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem>Help Center</DropdownMenuItem>
          <DropdownMenuItem>Documentation</DropdownMenuItem>
          <DropdownMenuItem>Contact Support</DropdownMenuItem>
          <DropdownMenuItem>FAQs</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* User Profile */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <div className="flex items-center gap-2 cursor-pointer">
            <div className="text-right hidden md:block">
              <div className="font-semibold">ADMIN</div>
              <div className="text-sm text-gray-500">Esther Howard</div>
            </div>
            <Avatar className="h-8 w-8">
              <AvatarImage src="" alt="User" />
              <AvatarFallback>EH</AvatarFallback>
            </Avatar>
            <ChevronDown size={16} />
          </div>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem>Profile</DropdownMenuItem>
          <DropdownMenuItem>Account Settings</DropdownMenuItem>
          <DropdownMenuItem>Sign out</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};
