
import { Outlet } from "react-router-dom";

export const DashboardContent = () => {
  return (
    <div className="flex-1 flex flex-col overflow-auto">
      <Outlet />
    </div>
  );
};
