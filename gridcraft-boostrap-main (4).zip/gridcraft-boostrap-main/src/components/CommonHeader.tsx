
import { Bell, HelpCircle, ChevronDown } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";

interface CommonHeaderProps {
  title: string;
  subtitle?: string;
  breadcrumbs?: Array<{label: string, path?: string}>;
}

export const CommonHeader = ({ title, subtitle, breadcrumbs }: CommonHeaderProps) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const notificationRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    };
    
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const notifications = [
    { id: 1, title: "Application Error", time: "Just now", type: "error" },
    { id: 2, title: "Scheduled Job Failed", time: "Just now", type: "warning" }
  ];

  return (
    <div className="bg-white shadow-sm border-b border-gray-200">
      <div className="p-4 flex justify-between items-center">
        <div>
          {breadcrumbs && (
            <Breadcrumb className="mb-2">
              <BreadcrumbList>
                {breadcrumbs.map((item, index) => (
                  <BreadcrumbItem key={index}>
                    {index > 0 && <BreadcrumbSeparator />}
                    {item.path ? (
                      <BreadcrumbLink asChild>
                        <Link to={item.path}>{item.label}</Link>
                      </BreadcrumbLink>
                    ) : (
                      <BreadcrumbPage>{item.label}</BreadcrumbPage>
                    )}
                  </BreadcrumbItem>
                ))}
              </BreadcrumbList>
            </Breadcrumb>
          )}
          <h1 className="text-2xl font-semibold">{title}</h1>
          {subtitle && <p className="text-gray-500">{subtitle}</p>}
        </div>
        
        <div className="flex items-center gap-4">
          {/* Notifications */}
          <div className="relative" ref={notificationRef}>
            <button 
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-2 text-gray-600 hover:bg-gray-100 rounded-full relative"
            >
              <Bell size={20} />
              <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            
            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg z-50 border border-gray-200">
                <div className="p-4 border-b border-gray-200 flex justify-between items-center">
                  <span className="font-medium">You have 4 new notifications</span>
                  <button className="text-blue-500 text-sm">Mark all as Read</button>
                </div>
                <div className="max-h-96 overflow-auto">
                  {notifications.map((notification) => (
                    <div 
                      key={notification.id}
                      className="p-4 border-b border-gray-100 hover:bg-gray-50 flex items-start gap-3"
                    >
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                        notification.type === 'error' ? 'bg-amber-100 text-amber-600' : 
                        notification.type === 'warning' ? 'bg-green-100 text-green-600' : 'bg-blue-100 text-blue-600'
                      }`}>
                        {notification.type === 'error' ? '!' : '✓'}
                      </div>
                      <div>
                        <div className="font-medium">{notification.title}</div>
                        <div className="text-sm text-gray-500">{notification.time}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          {/* Support */}
          <Popover>
            <PopoverTrigger asChild>
              <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-full">
                <HelpCircle size={20} />
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-64 p-0">
              <div className="py-2 px-4 bg-gray-50 font-medium border-b">Support</div>
              <div className="py-1">
                <Link to="#" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-100">
                  <span className="text-blue-500">📚</span>
                  <span>Knowledge Base and FAQ</span>
                </Link>
                <Link to="#" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-100">
                  <span className="text-blue-500">📧</span>
                  <span>Contact Support</span>
                </Link>
                <Link to="#" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-100">
                  <span className="text-blue-500">📝</span>
                  <span>Send Feedback</span>
                </Link>
                <Link to="#" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-100">
                  <span className="text-blue-500">👥</span>
                  <span>Refer-A-Colleague</span>
                </Link>
              </div>
            </PopoverContent>
          </Popover>
          
          <div className="flex items-center gap-2 ml-2">
            <Avatar className="h-8 w-8 border">
              <AvatarImage src="https://github.com/shadcn.png" alt="Profile" />
              <AvatarFallback>AD</AvatarFallback>
            </Avatar>
            <div className="flex flex-col text-right">
              <span className="text-xs font-medium">ADMIN</span>
              <span className="text-xs text-gray-500">Esther Howard</span>
            </div>
            <ChevronDown size={14} />
          </div>
        </div>
      </div>
    </div>
  );
};
