
import { X } from "lucide-react";
import Badge from "./Badge";
import { Button } from "./ui/button";

interface PatientCardProps {
  onClose?: () => void;
}

const PatientCard = ({ onClose }: PatientCardProps) => {
  return (
    <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-6 animate-fadeIn">
      <div className="flex justify-between items-start mb-6">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
            <span className="text-white text-sm font-semibold">IC</span>
          </div>
          <h2 className="text-xl font-semibold text-gray-800">INBOUND CALL</h2>
        </div>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-600 transition-colors"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="text-right text-gray-600">Patient Name:</div>
          <div className="font-medium">Bruce K Wayne</div>

          <div className="text-right text-gray-600">DOB:</div>
          <div className="font-medium">04/07/2016</div>

          <div className="text-right text-gray-600">Contact Number:</div>
          <div className="font-medium">(234) 234-2342</div>

          <div className="text-right text-gray-600">Alerts:</div>
          <div>
            <Badge variant="warning">Do not schedule, Patient in Collections</Badge>
          </div>

          <div className="text-right text-gray-600">Last Visit Summary:</div>
          <div className="font-medium">01/11/2024 | Annual</div>
        </div>

        <div className="mt-6">
          <div className="text-right text-gray-600 mb-2">Insurance:</div>
          <div className="pl-[50%] space-y-2">
            <p className="font-medium">Insurance Details: Show primaries then secondaries that are active</p>
            <p className="font-medium">Medicare (PMI) | Insured ID: 132745</p>
            <p className="font-medium">Vision Service Plan (PV) | Insured ID: 134980</p>
            <p className="font-medium">Carefirst Blue Cross Blue Shield (M&V) | Insured ID: 34746</p>
          </div>
        </div>

        <div className="mt-6">
          <div className="text-right text-gray-600 mb-2">Upcoming Appointment:</div>
          <div className="pl-[50%] space-y-2">
            <p className="font-medium">01/20/2025 | 10:00 AM | OCT-OU | KW</p>
            <p className="font-medium">02/01/2025 | 02:20 PM | Vision Screening |SC</p>
            <p className="font-medium">03/19/2025 | 9-9.30 AM | Comprehensive Eye Exam | KW</p>
          </div>
        </div>

        <div className="mt-6">
          <div className="text-right text-gray-600 mb-2">Balance & Payment:</div>
          <div className="pl-[50%]">
            <p className="font-medium">
              Credits: $50.05 | Pt Bal: 181.00 | Family Bal: $ 189.51 | Total Bal: $189.51
            </p>
          </div>
        </div>
      </div>

      <div className="mt-8 flex gap-4 justify-center">
        <Button
          variant="default"
          className="bg-blue-500 hover:bg-blue-600 transition-colors"
        >
          Patient Record
        </Button>
        <Button
          variant="outline"
          className="text-blue-500 border-blue-500 hover:bg-blue-50"
        >
          Book Appointment
        </Button>
      </div>
    </div>
  );
};

export default PatientCard;
