
import { LogOut, Settings, User } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Link } from "react-router-dom";

export const ProfileDropdown = () => {
  return (
    <div className="absolute right-0 mt-2 w-56 bg-white rounded-md shadow-lg border z-50">
      <div className="p-4 border-b">
        <div className="flex items-center gap-3">
          <Avatar>
            <AvatarImage src="https://github.com/shadcn.png" alt="Profile" />
            <AvatarFallback>AD</AvatarFallback>
          </Avatar>
          <div>
            <p className="font-medium">Esther Howard</p>
            <p className="text-xs text-gray-500">esther@example.com</p>
          </div>
        </div>
      </div>
      
      <div className="py-1">
        <Link to="/profile" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-100 text-sm">
          <User size={16} className="text-gray-500" />
          <span>Profile</span>
        </Link>
        <Link to="/settings" className="flex items-center gap-3 px-4 py-2 hover:bg-gray-100 text-sm">
          <Settings size={16} className="text-gray-500" />
          <span>Settings</span>
        </Link>
        <button className="w-full flex items-center gap-3 px-4 py-2 hover:bg-gray-100 text-sm">
          <LogOut size={16} className="text-gray-500" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
};
