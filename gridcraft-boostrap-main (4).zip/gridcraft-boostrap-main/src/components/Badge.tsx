
import { cn } from "@/lib/utils";

interface BadgeProps {
  children: React.ReactNode;
  variant?: "warning" | "info";
  className?: string;
}

const Badge = ({ children, variant = "info", className }: BadgeProps) => {
  return (
    <span
      className={cn(
        "inline-block px-3 py-1 text-sm font-medium rounded-full",
        variant === "warning" && "bg-red-100 text-red-800",
        variant === "info" && "bg-blue-100 text-blue-800",
        className
      )}
    >
      {children}
    </span>
  );
};

export default Badge;
