
import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { 
  Home, 
  FileCheck, 
  CheckCircle, 
  DollarSign, 
  AlertCircle, 
  Settings, 
  ChevronDown,
  ChevronRight
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Button } from "./ui/button";

export const Sidebar = () => {
  const location = useLocation();
  const [expandedMenus, setExpandedMenus] = useState<Record<string, boolean>>({
    "insurance-eligibility": true
  });

  const toggleSubmenu = (menu: string) => {
    setExpandedMenus(prev => ({
      ...prev,
      [menu]: !prev[menu]
    }));
  };

  const isActive = (path: string) => location.pathname === path;
  const isSubActive = (mainPath: string) => location.pathname.startsWith(mainPath);

  return (
    <div className="w-64 bg-white text-gray-700 shadow-md min-h-screen p-4 hidden md:flex md:flex-col">
      <div className="mb-6 flex justify-center">
        <img 
          src="/lovable-uploads/2cf411d1-73ae-4abd-aff0-d9e607280a9c.png" 
          alt="Logo" 
          className="h-12" 
        />
      </div>
      
      <div className="mb-6 flex items-center gap-2">
        <Select defaultValue="organization1">
          <SelectTrigger className="border-none bg-transparent focus:ring-0 text-gray-700">
            <SelectValue placeholder="Select org" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="organization1">Keplr Vision Group</SelectItem>
            <SelectItem value="organization2">Organization 2</SelectItem>
            <SelectItem value="organization3">Organization 3</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-1 flex-1 overflow-auto">
        <Link 
          to="/" 
          className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-colors ${
            isActive('/') ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'
          }`}
        >
          <Home size={20} className={`${isActive('/') ? 'text-blue-600' : 'text-red-500'}`} />
          <span>Dashboard</span>
        </Link>
        
        <div>
          <div 
            onClick={() => toggleSubmenu('insurance-eligibility')}
            className={`flex items-center justify-between gap-3 px-4 py-2 rounded-lg transition-colors cursor-pointer ${
              isSubActive('/insurance-eligibility') ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'
            }`}
          >
            <div className="flex items-center gap-3">
              <CheckCircle size={20} className={isSubActive('/insurance-eligibility') ? 'text-blue-600' : 'text-orange-500'} />
              <span>Insurance Eligibility</span>
            </div>
            {expandedMenus['insurance-eligibility'] ? 
              <ChevronDown size={16} className="transition-transform" /> : 
              <ChevronRight size={16} className="transition-transform" />
            }
          </div>
          {expandedMenus['insurance-eligibility'] && (
            <div className="pl-10 mt-1 space-y-1">
              <Link 
                to="/insurance-eligibility/status-enquiry" 
                className={`block px-4 py-2 rounded-lg text-sm transition-colors ${
                  isActive('/insurance-eligibility/status-enquiry') ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'
                }`}
              >
                Status & Enquiry
              </Link>
              <Link 
                to="/insurance-eligibility/overview" 
                className={`block px-4 py-2 rounded-lg text-sm transition-colors ${
                  isActive('/insurance-eligibility/overview') ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'
                }`}
              >
                Eligibility Overview
              </Link>
            </div>
          )}
        </div>
        
        <Link 
          to="/claim-submission" 
          className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-colors ${
            isActive('/claim-submission') ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'
          }`}
        >
          <FileCheck size={20} className={isActive('/claim-submission') ? 'text-blue-600' : 'text-green-500'} />
          <span>Claims Submission</span>
        </Link>
        
        <Link 
          to="/payment-posting" 
          className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-colors ${
            isActive('/payment-posting') ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'
          }`}
        >
          <DollarSign size={20} className={isActive('/payment-posting') ? 'text-blue-600' : 'text-purple-500'} />
          <span>Payment Posting</span>
        </Link>
        
        <Link 
          to="/ar-denials" 
          className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-colors ${
            isActive('/ar-denials') ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'
          }`}
        >
          <AlertCircle size={20} className={isActive('/ar-denials') ? 'text-blue-600' : 'text-red-500'} />
          <span>AR/Denials</span>
        </Link>
        
        <Link 
          to="/settings" 
          className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-colors ${
            isActive('/settings') ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'
          }`}
        >
          <Settings size={20} className={isActive('/settings') ? 'text-blue-600' : 'text-gray-500'} />
          <span>Settings</span>
        </Link>
      </div>

      <div className="mt-auto pt-4 flex justify-center">
        <img 
          src="/lovable-uploads/2cf411d1-73ae-4abd-aff0-d9e607280a9c.png" 
          alt="Logo" 
          className="h-10" 
        />
      </div>
    </div>
  );
};
