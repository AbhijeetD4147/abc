
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

interface Column {
  id: string;
  header: string;
}

interface DataTableProps {
  data: any[];
  columns: Column[];
  searchable?: boolean;
  pagination?: boolean;
}

export const DataTable = ({ 
  data,
  columns,
  searchable = true,
  pagination = true 
}: DataTableProps) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(50);
  const [searchTerms, setSearchTerms] = useState<Record<string, string>>({});

  // Filter data based on search terms
  const filteredData = data.filter(row => {
    // If no search terms are set, include all rows
    if (Object.keys(searchTerms).length === 0) return true;
    
    // Check if any search term matches the corresponding column value
    return Object.entries(searchTerms).every(([columnId, term]) => {
      if (!term) return true;
      const value = row[columnId];
      return String(value).toLowerCase().includes(term.toLowerCase());
    });
  });

  // Paginate data
  const startIndex = (currentPage - 1) * rowsPerPage;
  const paginatedData = pagination 
    ? filteredData.slice(startIndex, startIndex + rowsPerPage) 
    : filteredData;

  // Handle search input for a specific column
  const handleSearch = (columnId: string, value: string) => {
    setSearchTerms(prev => ({
      ...prev,
      [columnId]: value
    }));
    setCurrentPage(1); // Reset to first page on search
  };

  // Function to generate pagination controls
  const renderPagination = () => {
    const totalPages = Math.ceil(filteredData.length / rowsPerPage);
    
    return (
      <div className="flex items-center justify-between p-4 border-t">
        <div className="flex items-center gap-2">
          <span className="text-sm">Select Rows</span>
          <select 
            className="border rounded px-2 py-1 text-sm"
            value={rowsPerPage}
            onChange={(e) => setRowsPerPage(Number(e.target.value))}
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
        </div>
        
        <div className="flex items-center gap-2">
          <button 
            className="px-3 py-1 border rounded text-sm disabled:opacity-50"
            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
          >
            Prev
          </button>
          
          {/* Page numbers */}
          <div className="flex items-center">
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              // Logic to show relevant page numbers
              let pageNum;
              if (totalPages <= 5) {
                pageNum = i + 1;
              } else if (currentPage <= 3) {
                pageNum = i + 1;
              } else if (currentPage >= totalPages - 2) {
                pageNum = totalPages - 4 + i;
              } else {
                pageNum = currentPage - 2 + i;
              }
              
              return (
                <button 
                  key={i}
                  className={`w-8 h-8 flex items-center justify-center rounded ${
                    currentPage === pageNum ? 'bg-blue-500 text-white' : 'hover:bg-gray-100'
                  }`}
                  onClick={() => setCurrentPage(pageNum)}
                >
                  {pageNum}
                </button>
              );
            })}
            
            {totalPages > 5 && currentPage < totalPages - 2 && (
              <>
                <span className="px-1">...</span>
                <button
                  className="w-8 h-8 flex items-center justify-center rounded hover:bg-gray-100"
                  onClick={() => setCurrentPage(totalPages)}
                >
                  {totalPages}
                </button>
              </>
            )}
          </div>
          
          <button 
            className="px-3 py-1 border rounded text-sm disabled:opacity-50"
            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
          >
            Next
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="border rounded-lg overflow-hidden bg-white">
      <Table>
        <TableHeader>
          <TableRow>
            {columns.map(column => (
              <TableHead key={column.id}>
                {column.header}
                {searchable && (
                  <div className="mt-2 relative">
                    <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search"
                      className="pl-8 h-8 text-sm"
                      value={searchTerms[column.id] || ''}
                      onChange={(e) => handleSearch(column.id, e.target.value)}
                    />
                  </div>
                )}
              </TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {paginatedData.length > 0 ? (
            paginatedData.map((row, rowIndex) => (
              <TableRow key={rowIndex}>
                {columns.map(column => (
                  <TableCell key={`${rowIndex}-${column.id}`}>
                    {row[column.id]}
                  </TableCell>
                ))}
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={columns.length} className="text-center py-4">
                No results found
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
      
      {pagination && renderPagination()}
    </div>
  );
};
