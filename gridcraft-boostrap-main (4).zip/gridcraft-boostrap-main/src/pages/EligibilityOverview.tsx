
import React, { useState } from 'react';
import { CommonHeader } from "@/components/CommonHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search } from "lucide-react";

const EligibilityOverview = () => {
  const [dateRange, setDateRange] = useState<string>('');
  const [insurance, setInsurance] = useState<string>('');
  const [groupBy, setGroupBy] = useState<string>('');
  const [location, setLocation] = useState<string>('');
  const [appointmentDate, setAppointmentDate] = useState<string>('');
  
  const insuranceData = [
    { name: 'VSP', total: 17, complete: 75, success: 16, failed: 62, successPercentage: '92%', failedPercentage: '3%' },
    { name: 'Evolve', total: 36, complete: 14, success: 31, failed: 35, successPercentage: '94%', failedPercentage: '34%' },
    { name: 'UHC', total: 38, complete: 6, success: 46, failed: 30, successPercentage: '82%', failedPercentage: '15%' },
    { name: 'Superior Vision', total: 56, complete: 21, success: 75, failed: 90, successPercentage: '18%', failedPercentage: '17%' },
  ];

  // Breadcrumb data
  const breadcrumbs = [
    { label: "Dashboard", path: "/" },
    { label: "Insurance Eligibility", path: "/insurance-eligibility" },
    { label: "Eligibility Overview" }
  ];

  return (
    <div className="flex-1 flex flex-col h-full">
      <CommonHeader
        title="Eligibility Overview"
        subtitle="Track and manage insurance eligibility"
        breadcrumbs={breadcrumbs}
      />
      
      <div className="p-6 overflow-auto">
        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="flex items-end gap-4">
                <div className="flex-1">
                  <p className="text-sm text-gray-500 mb-1">Date Range</p>
                  <Input type="date" value={dateRange} onChange={(e) => setDateRange(e.target.value)} />
                </div>
                
                <div className="flex-1">
                  <p className="text-sm text-gray-500 mb-1">Insurance</p>
                  <Select value={insurance} onValueChange={setInsurance}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="vsp">VSP</SelectItem>
                      <SelectItem value="evolve">Evolve</SelectItem>
                      <SelectItem value="uhc">UHC</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex-1">
                  <p className="text-sm text-gray-500 mb-1">Group By</p>
                  <Select value={groupBy} onValueChange={setGroupBy}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="location">Location</SelectItem>
                      <SelectItem value="provider">Provider</SelectItem>
                      <SelectItem value="insurance">Insurance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Button className="bg-blue-500 hover:bg-blue-600">Go</Button>
              </div>

              <div className="flex items-end gap-4">
                <div className="flex-1">
                  <p className="text-sm text-gray-500 mb-1">Appointment Date</p>
                  <Input type="date" value={appointmentDate} onChange={(e) => setAppointmentDate(e.target.value)} />
                </div>
                
                <div className="flex-1">
                  <p className="text-sm text-gray-500 mb-1">Location</p>
                  <Select value={location} onValueChange={setLocation}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Locations</SelectItem>
                      <SelectItem value="ny">New York</SelectItem>
                      <SelectItem value="la">Los Angeles</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Table Section */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead className="border px-4 py-2">
                      <div className="flex items-center">
                        Insurance
                        <div className="ml-2 relative flex items-center">
                          <Search className="h-4 w-4 text-gray-400 absolute left-2" />
                          <Input placeholder="Search" className="h-8 pl-8 py-1" />
                        </div>
                      </div>
                    </TableHead>
                    <TableHead className="border px-4 py-2">
                      <div className="flex items-center">
                        Total
                        <div className="ml-2 relative flex items-center">
                          <Search className="h-4 w-4 text-gray-400 absolute left-2" />
                          <Input placeholder="Search" className="h-8 pl-8 py-1" />
                        </div>
                      </div>
                    </TableHead>
                    <TableHead className="border px-4 py-2">
                      <div className="flex items-center">
                        Complete
                        <div className="ml-2 relative flex items-center">
                          <Search className="h-4 w-4 text-gray-400 absolute left-2" />
                          <Input placeholder="Search" className="h-8 pl-8 py-1" />
                        </div>
                      </div>
                    </TableHead>
                    <TableHead className="border px-4 py-2">
                      <div className="flex items-center">
                        Success
                        <div className="ml-2 relative flex items-center">
                          <Search className="h-4 w-4 text-gray-400 absolute left-2" />
                          <Input placeholder="Search" className="h-8 pl-8 py-1" />
                        </div>
                      </div>
                    </TableHead>
                    <TableHead className="border px-4 py-2">
                      <div className="flex items-center">
                        Failed
                        <div className="ml-2 relative flex items-center">
                          <Search className="h-4 w-4 text-gray-400 absolute left-2" />
                          <Input placeholder="Search" className="h-8 pl-8 py-1" />
                        </div>
                      </div>
                    </TableHead>
                    <TableHead className="border px-4 py-2">
                      <div className="flex items-center">
                        %Success
                        <div className="ml-2 relative flex items-center">
                          <Search className="h-4 w-4 text-gray-400 absolute left-2" />
                          <Input placeholder="Search" className="h-8 pl-8 py-1" />
                        </div>
                      </div>
                    </TableHead>
                    <TableHead className="border px-4 py-2">
                      <div className="flex items-center">
                        %Failed
                        <div className="ml-2 relative flex items-center">
                          <Search className="h-4 w-4 text-gray-400 absolute left-2" />
                          <Input placeholder="Search" className="h-8 pl-8 py-1" />
                        </div>
                      </div>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {insuranceData.map((row, index) => (
                    <TableRow key={index}>
                      <TableCell className="border px-4 py-2">{row.name}</TableCell>
                      <TableCell className="border px-4 py-2">{row.total}</TableCell>
                      <TableCell className="border px-4 py-2">{row.complete}</TableCell>
                      <TableCell className="border px-4 py-2">{row.success}</TableCell>
                      <TableCell className="border px-4 py-2">{row.failed}</TableCell>
                      <TableCell className="border px-4 py-2">{row.successPercentage}</TableCell>
                      <TableCell className="border px-4 py-2">{row.failedPercentage}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            
            {/* Pagination */}
            <div className="flex justify-between items-center p-4 border-t">
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-500">Select Rows</span>
                <Select defaultValue="50">
                  <SelectTrigger className="w-16 h-8">
                    <SelectValue placeholder="50" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10</SelectItem>
                    <SelectItem value="25">25</SelectItem>
                    <SelectItem value="50">50</SelectItem>
                    <SelectItem value="100">100</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">Prev</Button>
                <Button variant="outline" size="sm" className="bg-blue-500 text-white">1</Button>
                <Button variant="outline" size="sm">2</Button>
                <Button variant="outline" size="sm">3</Button>
                <span>...</span>
                <Button variant="outline" size="sm">10</Button>
                <Button variant="outline" size="sm">Next</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default EligibilityOverview;
