
import React from 'react';
import { CommonHeader } from "@/components/CommonHeader";
import { Card, CardContent } from "@/components/ui/card";
import { DataTable } from "@/components/DataTable";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Eye, Edit, Trash } from "lucide-react";

const columns = [
  { id: 'claimId', header: 'Claim ID' },
  { id: 'patientName', header: 'Patient Name' },
  { id: 'insurance', header: 'Insurance' },
  { id: 'denialReason', header: 'Denial Reason' },
  { id: 'amount', header: 'Amount' },
  { id: 'dateOfService', header: 'Date of Service' },
  { id: 'status', header: 'Status' },
  { 
    id: 'actions', 
    header: 'Actions',
    cell: () => (
      <div className="flex space-x-2">
        <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600">
          <Eye className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-green-600">
          <Edit className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600">
          <Trash className="h-4 w-4" />
        </Button>
      </div>
    )
  }
];

const rejectedData = [
  { claimId: 'C10045', patientName: 'John Smith', insurance: 'VSP', denialReason: 'Missing Info', amount: '$145.00', dateOfService: '2023-06-15', status: 'Rejected' },
  { claimId: 'C10046', patientName: 'Emily Johnson', insurance: 'Evolve', denialReason: 'Invalid Code', amount: '$320.50', dateOfService: '2023-06-14', status: 'Rejected' },
];

const deniedData = [
  { claimId: 'C10047', patientName: 'Robert Williams', insurance: 'UHC', denialReason: 'Not Covered', amount: '$85.25', dateOfService: '2023-06-10', status: 'Denied' },
  { claimId: 'C10048', patientName: 'Sarah Miller', insurance: 'VSP', denialReason: 'Out of Network', amount: '$195.30', dateOfService: '2023-06-05', status: 'Denied' },
];

const ArDenials = () => {
  // Breadcrumb data
  const breadcrumbs = [
    { label: "Dashboard", path: "/" },
    { label: "AR/Denials Management" }
  ];

  return (
    <div className="flex-1 flex flex-col h-full">
      <CommonHeader
        title="AR/Denials Management"
        subtitle="Track and manage claim rejections and denials"
        breadcrumbs={breadcrumbs}
      />
      
      <div className="flex-1 p-6 overflow-auto">
        <div className="flex justify-between mb-6">
          <h2 className="text-xl font-semibold">Rejections & Denials</h2>
          <div className="flex space-x-2">
            <Button>Export Data</Button>
            <Button variant="outline">Filter</Button>
          </div>
        </div>
        
        <Card>
          <CardContent className="p-6">
            <Tabs defaultValue="rejections">
              <TabsList className="mb-6">
                <TabsTrigger value="rejections">Rejections</TabsTrigger>
                <TabsTrigger value="denials">Denials</TabsTrigger>
                <TabsTrigger value="appeals">Appeals</TabsTrigger>
                <TabsTrigger value="resolved">Resolved</TabsTrigger>
              </TabsList>
              
              <TabsContent value="rejections">
                <DataTable 
                  data={rejectedData}
                  columns={columns}
                />
              </TabsContent>
              
              <TabsContent value="denials">
                <DataTable 
                  data={deniedData}
                  columns={columns}
                />
              </TabsContent>
              
              <TabsContent value="appeals">
                <div className="text-center py-10 text-gray-500">
                  No appeals found
                </div>
              </TabsContent>
              
              <TabsContent value="resolved">
                <div className="text-center py-10 text-gray-500">
                  No resolved claims found
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ArDenials;
