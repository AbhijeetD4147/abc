
import React from 'react';
import { CommonHeader } from "@/components/CommonHeader";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

const Settings = () => {
  return (
    <div className="flex-1 flex flex-col h-full">
      <CommonHeader 
        title="Settings" 
        subtitle="Configure application settings"
      />
      
      <div className="p-6 overflow-auto">
        <Tabs defaultValue="general">
          <div className="flex border-b mb-6">
            <TabsList className="bg-transparent">
              <TabsTrigger value="general" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-blue-600">
                General
              </TabsTrigger>
              <TabsTrigger value="organization" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-blue-600">
                Organization
              </TabsTrigger>
              <TabsTrigger value="users" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-blue-600">
                Users & Permissions
              </TabsTrigger>
              <TabsTrigger value="integrations" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-blue-600">
                Integrations
              </TabsTrigger>
              <TabsTrigger value="billing" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-blue-600">
                Billing
              </TabsTrigger>
              <TabsTrigger value="security" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-blue-600">
                Security
              </TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="general">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Application Settings</CardTitle>
                  <CardDescription>Configure general application settings.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="application-name">Application Name</Label>
                      <Input id="application-name" defaultValue="FastPay Health" />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="default-language">Default Language</Label>
                      <Select defaultValue="en">
                        <SelectTrigger id="default-language">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="en">English</SelectItem>
                          <SelectItem value="es">Spanish</SelectItem>
                          <SelectItem value="fr">French</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="timezone">Timezone</Label>
                      <Select defaultValue="est">
                        <SelectTrigger id="timezone">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="est">Eastern Time (ET)</SelectItem>
                          <SelectItem value="cst">Central Time (CT)</SelectItem>
                          <SelectItem value="mst">Mountain Time (MT)</SelectItem>
                          <SelectItem value="pst">Pacific Time (PT)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex items-center justify-between pt-2">
                      <Label htmlFor="dark-mode">Dark Mode</Label>
                      <Switch id="dark-mode" />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="notifications">Enable Notifications</Label>
                      <Switch id="notifications" defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="sound">Notification Sounds</Label>
                      <Switch id="sound" />
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Interface Customization</CardTitle>
                  <CardDescription>Customize the look and feel of your application.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="theme-color">Primary Color</Label>
                      <div className="flex gap-2">
                        <Input type="color" id="theme-color" defaultValue="#1E88E5" className="w-20 h-10" />
                        <Input defaultValue="#1E88E5" className="flex-1" />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Dashboard Layout</Label>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="border rounded-md p-2 flex items-center space-x-2 cursor-pointer">
                          <Checkbox id="default-layout" />
                          <label htmlFor="default-layout" className="text-sm cursor-pointer">Default Layout</label>
                        </div>
                        <div className="border rounded-md p-2 flex items-center space-x-2 cursor-pointer">
                          <Checkbox id="compact-layout" />
                          <label htmlFor="compact-layout" className="text-sm cursor-pointer">Compact Layout</label>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="table-density">Table Density</Label>
                      <Select defaultValue="comfortable">
                        <SelectTrigger id="table-density">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="comfortable">Comfortable</SelectItem>
                          <SelectItem value="standard">Standard</SelectItem>
                          <SelectItem value="compact">Compact</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex items-center justify-between pt-2">
                      <Label htmlFor="animations">Interface Animations</Label>
                      <Switch id="animations" defaultChecked />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="organization">
            <Card>
              <CardHeader>
                <CardTitle>Organization Details</CardTitle>
                <CardDescription>Manage your organization information.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="org-name">Organization Name</Label>
                    <Input id="org-name" defaultValue="Keplr Vision Group" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="org-id">Organization ID</Label>
                    <Input id="org-id" defaultValue="KVG-12345" readOnly className="bg-gray-50" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="org-email">Email</Label>
                    <Input id="org-email" type="email" defaultValue="admin@keplrvision.com" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="org-phone">Phone</Label>
                    <Input id="org-phone" type="tel" defaultValue="(555) 123-4567" />
                  </div>
                  
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="org-address">Address</Label>
                    <Input id="org-address" defaultValue="123 Vision Street, Suite 100" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="org-city">City</Label>
                    <Input id="org-city" defaultValue="Optics City" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="org-state">State</Label>
                    <Input id="org-state" defaultValue="California" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="org-zip">Zip Code</Label>
                    <Input id="org-zip" defaultValue="90210" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="org-country">Country</Label>
                    <Input id="org-country" defaultValue="United States" />
                  </div>
                </div>
                
                <div className="pt-4">
                  <Button>Save Changes</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="users">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Users & Permissions</CardTitle>
                    <CardDescription>Manage user accounts and roles.</CardDescription>
                  </div>
                  <Button>Add New User</Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-4">Name</th>
                        <th className="text-left py-3 px-4">Email</th>
                        <th className="text-left py-3 px-4">Role</th>
                        <th className="text-left py-3 px-4">Status</th>
                        <th className="text-right py-3 px-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b">
                        <td className="py-3 px-4">Esther Howard</td>
                        <td className="py-3 px-4">esther@keplrvision.com</td>
                        <td className="py-3 px-4">Administrator</td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">Active</span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <Button variant="ghost" size="sm">Edit</Button>
                        </td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4">Jane Cooper</td>
                        <td className="py-3 px-4">jane@keplrvision.com</td>
                        <td className="py-3 px-4">Manager</td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">Active</span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <Button variant="ghost" size="sm">Edit</Button>
                        </td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4">Robert Fox</td>
                        <td className="py-3 px-4">robert@keplrvision.com</td>
                        <td className="py-3 px-4">Staff</td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs">Invited</span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <Button variant="ghost" size="sm">Edit</Button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="integrations">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Practice Management Systems</CardTitle>
                  <CardDescription>Configure PMS integrations.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 bg-blue-100 rounded-md flex items-center justify-center text-blue-600 font-bold">
                        C
                      </div>
                      <div>
                        <h4 className="font-medium">Compulink</h4>
                        <p className="text-sm text-gray-500">Practice management software</p>
                      </div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 bg-green-100 rounded-md flex items-center justify-center text-green-600 font-bold">
                        E
                      </div>
                      <div>
                        <h4 className="font-medium">EyeMD EMR</h4>
                        <p className="text-sm text-gray-500">Electronic medical records</p>
                      </div>
                    </div>
                    <Switch />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 bg-purple-100 rounded-md flex items-center justify-center text-purple-600 font-bold">
                        N
                      </div>
                      <div>
                        <h4 className="font-medium">NextGen</h4>
                        <p className="text-sm text-gray-500">Healthcare technology solutions</p>
                      </div>
                    </div>
                    <Switch />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Insurance Portals</CardTitle>
                  <CardDescription>Connect to insurance provider portals.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 bg-blue-100 rounded-md flex items-center justify-center text-blue-600 font-bold">
                        V
                      </div>
                      <div>
                        <h4 className="font-medium">VSP</h4>
                        <p className="text-sm text-gray-500">Vision insurance provider</p>
                      </div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 bg-red-100 rounded-md flex items-center justify-center text-red-600 font-bold">
                        E
                      </div>
                      <div>
                        <h4 className="font-medium">Evolve</h4>
                        <p className="text-sm text-gray-500">Insurance portal</p>
                      </div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 bg-yellow-100 rounded-md flex items-center justify-center text-yellow-600 font-bold">
                        U
                      </div>
                      <div>
                        <h4 className="font-medium">UHC</h4>
                        <p className="text-sm text-gray-500">UnitedHealthcare</p>
                      </div>
                    </div>
                    <Switch />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="billing">
            <Card>
              <CardHeader>
                <CardTitle>Billing Information</CardTitle>
                <CardDescription>Manage your billing details and subscription.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                  <h3 className="font-medium text-blue-700">Current Plan: Professional</h3>
                  <p className="text-sm text-blue-600 mt-1">Your subscription renews on July 15, 2024</p>
                </div>
                
                <div className="border rounded-lg overflow-hidden">
                  <div className="p-4 bg-gray-50 font-medium">
                    Payment Method
                  </div>
                  <div className="p-4">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-12 bg-blue-100 rounded flex items-center justify-center text-blue-600 font-bold text-sm">
                          VISA
                        </div>
                        <div>
                          <p className="font-medium">Visa ending in 4242</p>
                          <p className="text-sm text-gray-500">Expires 12/2025</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">Change</Button>
                    </div>
                  </div>
                </div>
                
                <div className="border rounded-lg overflow-hidden">
                  <div className="p-4 bg-gray-50 font-medium">
                    Billing Address
                  </div>
                  <div className="p-4">
                    <p>Keplr Vision Group</p>
                    <p className="text-sm text-gray-500">123 Vision Street, Suite 100</p>
                    <p className="text-sm text-gray-500">Optics City, CA 90210</p>
                    <p className="text-sm text-gray-500">United States</p>
                    <Button variant="outline" size="sm" className="mt-2">Update</Button>
                  </div>
                </div>
                
                <div className="border rounded-lg overflow-hidden">
                  <div className="p-4 bg-gray-50 font-medium">
                    Billing History
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-3 px-4">Date</th>
                          <th className="text-left py-3 px-4">Description</th>
                          <th className="text-left py-3 px-4">Amount</th>
                          <th className="text-left py-3 px-4">Status</th>
                          <th className="text-right py-3 px-4">Receipt</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b">
                          <td className="py-3 px-4">Jun 15, 2024</td>
                          <td className="py-3 px-4">Professional Plan - Monthly</td>
                          <td className="py-3 px-4">$249.00</td>
                          <td className="py-3 px-4">
                            <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">Paid</span>
                          </td>
                          <td className="py-3 px-4 text-right">
                            <Button variant="ghost" size="sm">Download</Button>
                          </td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-3 px-4">May 15, 2024</td>
                          <td className="py-3 px-4">Professional Plan - Monthly</td>
                          <td className="py-3 px-4">$249.00</td>
                          <td className="py-3 px-4">
                            <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">Paid</span>
                          </td>
                          <td className="py-3 px-4 text-right">
                            <Button variant="ghost" size="sm">Download</Button>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="security">
            <Card>
              <CardHeader>
                <CardTitle>Security Settings</CardTitle>
                <CardDescription>Manage your account security preferences.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="font-medium">Password</h3>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="current-password">Current Password</Label>
                      <Input id="current-password" type="password" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="new-password">New Password</Label>
                      <Input id="new-password" type="password" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirm-password">Confirm New Password</Label>
                      <Input id="confirm-password" type="password" />
                    </div>
                  </div>
                  <Button>Update Password</Button>
                </div>
                
                <div className="border-t pt-4">
                  <h3 className="font-medium mb-4">Two-Factor Authentication</h3>
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="font-medium">Two-factor authentication</p>
                      <p className="text-sm text-gray-500">Add an extra layer of security to your account</p>
                    </div>
                    <Switch />
                  </div>
                  <Button variant="outline">Set Up 2FA</Button>
                </div>
                
                <div className="border-t pt-4">
                  <h3 className="font-medium mb-4">Sessions</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">Current Session</p>
                        <p className="text-sm text-gray-500">Chrome on Windows • San Francisco, CA • IP: 192.168.1.1</p>
                      </div>
                      <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">Active</span>
                    </div>
                    <Button variant="outline" className="text-red-600">Sign Out All Other Devices</Button>
                  </div>
                </div>
                
                <div className="border-t pt-4">
                  <h3 className="font-medium mb-4">API Access</h3>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">API Access</p>
                      <p className="text-sm text-gray-500">Allow API access to your account</p>
                    </div>
                    <Switch />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Settings;
