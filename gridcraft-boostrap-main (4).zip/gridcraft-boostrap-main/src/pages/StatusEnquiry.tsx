
import React, { useState } from 'react';
import { CommonHeader } from "@/components/CommonHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DateRangePicker } from "@/components/DateRangePicker";
import { DateRange } from "react-day-picker";
import { Search, Eye, Edit, Trash, Info } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const StatusEnquiry = () => {
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: new Date(),
    to: new Date()
  });
  
  const statusSummary = [
    { title: 'Total Appointments', value: 40, color: 'bg-blue-500 text-white' },
    { title: 'Req Calling', value: '08', color: 'bg-blue-500 text-white' },
    { title: 'Pending', value: '00', color: 'bg-blue-500 text-white' },
    { title: 'Completed', value: 28, color: 'bg-blue-500 text-white' },
    { title: 'Partial Completed', value: 28, color: 'bg-blue-500 text-white' },
    { title: 'Policy Next Month', value: 25, color: 'bg-blue-500 text-white' },
    { title: 'Failed', value: 25, color: 'bg-blue-500 text-white' },
  ];
  
  const patientData = [
    { id: 1, lastName: 'Walker', firstName: 'Andrew', dob: '04/08/2020', ssn: '-', age: '25', apptDate: '05/14/2024', provider: 'Ashley Adams', status: 'Need Policy ID' },
    { id: 2, lastName: 'Watson', firstName: 'Elizabeth', dob: '11/12/2022', ssn: '-', age: '22', apptDate: '08/22/2024', provider: 'Julia Lopez', status: 'Invalid DOB' },
    { id: 3, lastName: 'Taylor', firstName: 'Andrew', dob: '03/19/2010', ssn: '-', age: '38', apptDate: '05/27/2024', provider: 'Rafael Gomez', status: 'Need Subscriber ID' },
    { id: 4, lastName: 'Robinson', firstName: 'Ashley', dob: '07/02/1998', ssn: '-', age: '42', apptDate: '01/05/2024', provider: 'Joseph White', status: 'Provider not enrolled' },
    { id: 5, lastName: 'Taylor', firstName: 'Andrew', dob: '03/19/2010', ssn: '-', age: '38', apptDate: '05/27/2024', provider: 'Rafael Gomez', status: 'Invalid DOB' },
  ];

  return (
    <div className="flex-1 flex flex-col h-full">
      <CommonHeader 
        title="Status & Enquiry" 
        subtitle="Dashboard / Insurance Eligibility"
      />
      
      <div className="p-6">
        {/* Search Filters */}
        <Card className="p-4 mb-6">
          <div className="flex flex-wrap gap-4 items-end">
            <div>
              <p className="text-sm text-gray-500 mb-1">Date Range</p>
              <DateRangePicker 
                dateRange={dateRange}
                setDateRange={setDateRange}
              />
            </div>
            
            <div>
              <p className="text-sm text-gray-500 mb-1">Location</p>
              <Select>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Locations</SelectItem>
                  <SelectItem value="ny">New York</SelectItem>
                  <SelectItem value="la">Los Angeles</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button className="ml-auto">Go</Button>
          </div>
        </Card>
        
        {/* Status Summary */}
        <div className="flex overflow-x-auto mb-6">
          {statusSummary.map((status, index) => (
            <div key={index} className={`${status.color} min-w-[120px] flex-1 p-4 text-center flex flex-col items-center justify-center ${index > 0 ? 'border-l border-blue-400' : ''}`}>
              <div className="text-2xl font-bold">{status.value}</div>
              <div className="text-sm mt-1">{status.title}</div>
              {(status.title === 'Policy Next Month' || status.title === 'Partial Completed') && (
                <div className="absolute right-2 top-2">
                  <Info size={16} />
                </div>
              )}
            </div>
          ))}
        </div>
        
        {/* Patients Table */}
        <Card>
          <div className="p-4 flex justify-end">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
              <Input className="pl-10 max-w-xs" placeholder="Search" />
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10">
                    <Input type="checkbox" className="h-4 w-4" />
                  </TableHead>
                  <TableHead>Last Name</TableHead>
                  <TableHead>First Name</TableHead>
                  <TableHead>DOB</TableHead>
                  <TableHead>SSN</TableHead>
                  <TableHead>Age</TableHead>
                  <TableHead>Appt Date</TableHead>
                  <TableHead>Provider</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {patientData.map((patient) => (
                  <TableRow key={patient.id}>
                    <TableCell>
                      <Input type="checkbox" className="h-4 w-4" />
                    </TableCell>
                    <TableCell className="font-medium text-blue-600">{patient.lastName}</TableCell>
                    <TableCell>{patient.firstName}</TableCell>
                    <TableCell>{patient.dob}</TableCell>
                    <TableCell>{patient.ssn}</TableCell>
                    <TableCell>{patient.age}</TableCell>
                    <TableCell>{patient.apptDate}</TableCell>
                    <TableCell>{patient.provider}</TableCell>
                    <TableCell>
                      <span className={patient.status.includes('Invalid') ? 'text-red-500' : 'text-yellow-600'}>
                        {patient.status}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-green-600">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600">
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          <div className="p-4 flex justify-between items-center">
            <div className="flex gap-4">
              <Button variant="outline" size="sm">Expand All</Button>
              <Button variant="outline" size="sm">Collapse All</Button>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-500">Select Rows</span>
                <Select defaultValue="50">
                  <SelectTrigger className="w-16">
                    <SelectValue placeholder="50" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10</SelectItem>
                    <SelectItem value="25">25</SelectItem>
                    <SelectItem value="50">50</SelectItem>
                    <SelectItem value="100">100</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" disabled>Prev</Button>
                <Button variant="outline" size="sm" className="bg-blue-50 text-blue-600">1</Button>
                <Button variant="outline" size="sm">2</Button>
                <Button variant="outline" size="sm">3</Button>
                <span>...</span>
                <Button variant="outline" size="sm">10</Button>
                <Button variant="outline" size="sm">Next</Button>
              </div>
            </div>
          </div>
          
          <div className="p-4 border-t flex gap-2 justify-center">
            <Button className="bg-blue-600 hover:bg-blue-700">Update from PMS</Button>
            <Button className="bg-blue-600 hover:bg-blue-700">Eligibility Request</Button>
            <Button className="bg-blue-600 hover:bg-blue-700">Push Data to PMS</Button>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default StatusEnquiry;
