
import React, { useState } from 'react';
import { CommonHeader } from "@/components/CommonHeader";
import { Card, CardContent } from "@/components/ui/card";
import { DataTable } from "@/components/DataTable";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DateRange } from "react-day-picker";
import { DateRangePicker } from "@/components/DateRangePicker";
import { Search, Eye, Edit, Trash } from "lucide-react";

const columns = [
  { id: 'eobId', header: 'EOB ID' },
  { id: 'patientName', header: 'Patient Name' },
  { id: 'insurance', header: 'Insurance' },
  { id: 'amount', header: 'Amount' },
  { id: 'receivedDate', header: 'Received Date' },
  { id: 'status', header: 'Status' },
  { 
    id: 'actions', 
    header: 'Actions',
    cell: () => (
      <div className="flex space-x-2">
        <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600">
          <Eye className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-green-600">
          <Edit className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600">
          <Trash className="h-4 w-4" />
        </Button>
      </div>
    )
  }
];

const pendingData = [
  { eobId: 'EOB10045', patientName: 'John Smith', insurance: 'VSP', amount: '$145.00', receivedDate: '2023-06-15', status: 'Pending' },
  { eobId: 'EOB10046', patientName: 'Emily Johnson', insurance: 'Evolve', amount: '$320.50', receivedDate: '2023-06-14', status: 'Pending' },
  { eobId: 'EOB10047', patientName: 'Robert Williams', insurance: 'UHC', amount: '$85.25', receivedDate: '2023-06-10', status: 'Pending' },
];

const postedData = [
  { eobId: 'EOB10042', patientName: 'Mary Brown', insurance: 'Superior Vision', amount: '$250.75', receivedDate: '2023-06-08', status: 'Posted' },
  { eobId: 'EOB10043', patientName: 'David Jones', insurance: 'VSP', amount: '$195.30', receivedDate: '2023-06-05', status: 'Posted' },
  { eobId: 'EOB10044', patientName: 'Sarah Miller', insurance: 'Evolve', amount: '$430.00', receivedDate: '2023-06-01', status: 'Posted' },
];

const PaymentPosting = () => {
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: new Date(),
    to: new Date()
  });
  
  return (
    <div className="flex-1 flex flex-col h-full">
      <CommonHeader
        title="Payment Posting"
        subtitle="Track and manage insurance payments"
      />
      
      <div className="p-6 overflow-auto">
        {/* Search Filters */}
        <Card className="p-4 mb-6">
          <div className="flex flex-wrap gap-4 items-end">
            <div>
              <p className="text-sm text-gray-500 mb-1">Date Range</p>
              <DateRangePicker 
                dateRange={dateRange}
                setDateRange={setDateRange}
              />
            </div>
            
            <div>
              <p className="text-sm text-gray-500 mb-1">Insurance</p>
              <Select>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="vsp">VSP</SelectItem>
                  <SelectItem value="evolve">Evolve</SelectItem>
                  <SelectItem value="superior">Superior Vision</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <p className="text-sm text-gray-500 mb-1">Status</p>
              <Select>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="posted">Posted</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="relative">
              <p className="text-sm text-gray-500 mb-1">Search</p>
              <div className="flex">
                <Input placeholder="Search by EOB ID, patient..." className="rounded-r-none" />
                <Button className="rounded-l-none" variant="secondary">
                  <Search size={16} />
                </Button>
              </div>
            </div>
            
            <Button className="ml-auto">Apply Filters</Button>
          </div>
        </Card>
        
        {/* Payment Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
            <CardContent className="p-4">
              <h3 className="text-sm font-medium opacity-80">Total EOBs Downloaded</h3>
              <div className="text-2xl font-bold mt-2">85</div>
              <div className="text-xs mt-1 opacity-80">Last 30 days</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
            <CardContent className="p-4">
              <h3 className="text-sm font-medium opacity-80">Payments Posted in PMS</h3>
              <div className="text-2xl font-bold mt-2">60</div>
              <div className="text-xs mt-1 opacity-80">Last 30 days</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white">
            <CardContent className="p-4">
              <h3 className="text-sm font-medium opacity-80">EOBs Pending to Post</h3>
              <div className="text-2xl font-bold mt-2">25</div>
              <div className="text-xs mt-1 opacity-80">Action required</div>
            </CardContent>
          </Card>
        </div>
        
        {/* Payments Table */}
        <Card>
          <CardContent className="p-6">
            <Tabs defaultValue="pending">
              <TabsList className="mb-6">
                <TabsTrigger value="pending">Pending</TabsTrigger>
                <TabsTrigger value="posted">Posted</TabsTrigger>
                <TabsTrigger value="failed">Failed</TabsTrigger>
                <TabsTrigger value="adjustments">Adjustments</TabsTrigger>
              </TabsList>
              
              <TabsContent value="pending">
                <DataTable 
                  data={pendingData}
                  columns={columns}
                />
                <div className="mt-4 flex justify-center gap-2">
                  <Button className="bg-blue-600 hover:bg-blue-700">Post Selected Payments</Button>
                  <Button variant="outline">Download EOB</Button>
                </div>
              </TabsContent>
              
              <TabsContent value="posted">
                <DataTable 
                  data={postedData}
                  columns={columns}
                />
              </TabsContent>
              
              <TabsContent value="failed">
                <div className="text-center py-10 text-gray-500">
                  No failed payments found
                </div>
              </TabsContent>
              
              <TabsContent value="adjustments">
                <div className="text-center py-10 text-gray-500">
                  No adjustments found
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PaymentPosting;
