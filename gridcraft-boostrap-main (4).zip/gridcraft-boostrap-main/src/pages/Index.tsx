
import { Sidebar } from "@/components/Sidebar";
import { useIsMobile } from "@/hooks/use-mobile";
import { useState } from "react";
import { Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Outlet } from "react-router-dom";

const Index = () => {
  const isMobile = useIsMobile();
  const [showSidebar, setShowSidebar] = useState(false);

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Mobile Sidebar */}
      {isMobile && showSidebar && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40" onClick={() => setShowSidebar(false)}>
          <div className="w-64 bg-white h-full" onClick={(e) => e.stopPropagation()}>
            <Sidebar />
          </div>
        </div>
      )}

      {/* Desktop Sidebar */}
      {!isMobile && <Sidebar />}

      {/* Main Content */}
      <div className="flex-1 overflow-hidden flex flex-col w-full">
        {isMobile && (
          <div className="p-4 flex items-center">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowSidebar(true)}
              className="mr-2"
            >
              <Menu size={24} />
            </Button>
            <img src="/lovable-uploads/2cf411d1-73ae-4abd-aff0-d9e607280a9c.png" alt="Logo" className="h-6" />
          </div>
        )}
        
        <div className="flex-1 overflow-auto w-full">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default Index;
