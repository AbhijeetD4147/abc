
import React, { useState } from 'react';
import { CommonHeader } from "@/components/CommonHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, RotateCw, Eye, Edit, Trash } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const filters = [
  { id: 'claims-in-process', label: 'Claims In Process', color: 'bg-blue-100 text-blue-600' },
  { id: 'cob-to-vision-ins', label: 'COB to Vision Ins', color: 'bg-blue-100 text-blue-600' },
  { id: 'open', label: 'Open', color: 'bg-blue-100 text-blue-600' },
  { id: 'pa-pending', label: 'PA Pending', color: 'bg-blue-100 text-blue-600' },
  { id: 'paid-in-full', label: 'Paid In Full', color: 'bg-blue-100 text-blue-600' },
  { id: 'ready-for-claim', label: 'Ready For Claim', color: 'bg-blue-100 text-blue-600' },
  { id: 'referral-pending', label: 'Referral Pending', color: 'bg-blue-100 text-blue-600' },
  { id: 'on-hold', label: 'On Hold', color: 'bg-blue-100 text-blue-600' }
];

const claimData = [
  { practiceLocation: 'Adams', providerName: 'Ashley', insuranceName: 'Beaver Vision', patientName: 'VSP Primary', serviceDate: '13/01/2024', billNumber: '243', chargeAmt: '$50.62', insuranceAmount: '$50.62', billType: '', billStatus: '', claimStatus: '', submissionDate: '13/01/2024', remarks: '' },
  { practiceLocation: 'Lopez', providerName: 'Julia', insuranceName: 'Beaver Vision', patientName: 'JuliaOrt...', serviceDate: '10/09/2022', billNumber: '495', chargeAmt: '$39.34', insuranceAmount: '$39.34', billType: '', billStatus: '', claimStatus: '', submissionDate: '10/09/2022', remarks: '' },
  { practiceLocation: 'Gomez', providerName: 'Rafael', insuranceName: 'Beaver Vision', patientName: 'Rafael E...', serviceDate: '22/03/2023', billNumber: '463', chargeAmt: '$52.76', insuranceAmount: '$52.76', billType: '', billStatus: '', claimStatus: '', submissionDate: '22/03/2023', remarks: '' },
  { practiceLocation: 'White', providerName: 'Joseph', insuranceName: 'Beaver Vision', patientName: 'Joseph...', serviceDate: '23/12/2020', billNumber: '661', chargeAmt: '$66.76', insuranceAmount: '$66.76', billType: '', billStatus: '', claimStatus: '', submissionDate: '23/12/2020', remarks: '' }
];

const ClaimSubmission = () => {
  // Breadcrumb data
  const breadcrumbs = [
    { label: "Dashboard", path: "/" },
    { label: "Claim Submission" }
  ];

  return (
    <div className="flex-1 flex flex-col h-full">
      <CommonHeader
        title="Claim Submission"
        subtitle="Manage and submit insurance claims"
        breadcrumbs={breadcrumbs}
      />
      
      <div className="p-6 overflow-auto">
        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-gray-500 mb-1">Location</p>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Locations</SelectItem>
                    <SelectItem value="adams">Adams</SelectItem>
                    <SelectItem value="lopez">Lopez</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <p className="text-sm text-gray-500 mb-1">Superbill/Patient ID#</p>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <p className="text-sm text-gray-500 mb-1">Claim Status</p>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="submitted">Submitted</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <p className="text-sm text-gray-500 mb-1">Service Date</p>
                <div className="flex">
                  <Input type="date" className="rounded-r-none" />
                  <Button variant="outline" className="rounded-l-none border-l-0">
                    <Search size={16} />
                  </Button>
                </div>
              </div>
              
              <div>
                <p className="text-sm text-gray-500 mb-1">Ins Name</p>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="beaver">Beaver Vision</SelectItem>
                    <SelectItem value="vsp">VSP</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <p className="text-sm text-gray-500 mb-1">HCFA Type</p>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <p className="text-sm text-gray-500 mb-1">Provider ID</p>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <p className="text-sm text-gray-500 mb-1">Submission Date</p>
                <div className="flex">
                  <Input type="date" className="rounded-r-none" />
                  <Button variant="outline" className="rounded-l-none border-l-0">
                    <Search size={16} />
                  </Button>
                </div>
              </div>
              
              <div className="flex items-end">
                <div className="flex gap-2">
                  <Button variant="ghost" size="icon">
                    <RotateCw size={16} />
                  </Button>
                  <Button className="bg-blue-600 hover:bg-blue-700">Go</Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Tabs */}
        <Tabs defaultValue="bill-status">
          <TabsList className="mb-4">
            <TabsTrigger value="bill-status">Bill Status</TabsTrigger>
            <TabsTrigger value="by-claims">By Claims</TabsTrigger>
            <TabsTrigger value="by-insurance">By Insurance</TabsTrigger>
            <TabsTrigger value="by-practice-location">By Practice Location</TabsTrigger>
            <TabsTrigger value="by-provider">By Provider</TabsTrigger>
            <TabsTrigger value="by-aging">By Aging</TabsTrigger>
          </TabsList>
          
          <TabsContent value="bill-status">
            {/* Filters */}
            <div className="mb-4 flex flex-wrap gap-2">
              <div className="text-sm font-medium mr-2 flex items-center">
                Attention Submitter
              </div>
              {filters.map(filter => (
                <Button 
                  key={filter.id} 
                  variant="outline" 
                  className={`rounded-full text-xs py-1 px-3 ${filter.color}`}
                  size="sm"
                >
                  {filter.label}
                </Button>
              ))}
            </div>
            
            {/* Search */}
            <div className="flex justify-end mb-4">
              <div className="relative">
                <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input placeholder="Search" className="pl-9 w-64" />
              </div>
            </div>
            
            {/* Table */}
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead className="w-10 border">
                      <Input type="checkbox" className="h-4 w-4" />
                    </TableHead>
                    <TableHead className="border">Practice Location</TableHead>
                    <TableHead className="border">Provider Name</TableHead>
                    <TableHead className="border">Insurance Name</TableHead>
                    <TableHead className="border">Patient Name</TableHead>
                    <TableHead className="border">Service Date</TableHead>
                    <TableHead className="border">Bill Number</TableHead>
                    <TableHead className="border">Charge Amt</TableHead>
                    <TableHead className="border">Insurance Amount</TableHead>
                    <TableHead className="border">Bill Type</TableHead>
                    <TableHead className="border">Bill Status</TableHead>
                    <TableHead className="border">Claim Status</TableHead>
                    <TableHead className="border">Submission Date</TableHead>
                    <TableHead className="border">Remarks</TableHead>
                    <TableHead className="border">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {claimData.map((claim, index) => (
                    <TableRow key={index}>
                      <TableCell className="border">
                        <Input type="checkbox" className="h-4 w-4" />
                      </TableCell>
                      <TableCell className="border">{claim.practiceLocation}</TableCell>
                      <TableCell className="border">{claim.providerName}</TableCell>
                      <TableCell className="border">{claim.insuranceName}</TableCell>
                      <TableCell className="border">{claim.patientName}</TableCell>
                      <TableCell className="border">{claim.serviceDate}</TableCell>
                      <TableCell className="border">{claim.billNumber}</TableCell>
                      <TableCell className="border">{claim.chargeAmt}</TableCell>
                      <TableCell className="border">{claim.insuranceAmount}</TableCell>
                      <TableCell className="border">{claim.billType}</TableCell>
                      <TableCell className="border">{claim.billStatus}</TableCell>
                      <TableCell className="border">
                        <Select>
                          <SelectTrigger className="h-8 w-28">
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">Pending</SelectItem>
                            <SelectItem value="submitted">Submitted</SelectItem>
                            <SelectItem value="denied">Denied</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell className="border">{claim.submissionDate}</TableCell>
                      <TableCell className="border">{claim.remarks}</TableCell>
                      <TableCell className="border">
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-green-600">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600">
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            
            {/* Pagination */}
            <div className="mt-4 flex justify-between items-center">
              <div className="flex gap-4">
                <Button variant="outline" size="sm">Expand All</Button>
                <Button variant="outline" size="sm">Collapse All</Button>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-500">Select Rows</span>
                  <Select defaultValue="50">
                    <SelectTrigger className="w-16">
                      <SelectValue placeholder="50" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="10">10</SelectItem>
                      <SelectItem value="25">25</SelectItem>
                      <SelectItem value="50">50</SelectItem>
                      <SelectItem value="100">100</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" disabled>Prev</Button>
                  <Button variant="outline" size="sm" className="bg-blue-50 text-blue-600">1</Button>
                  <Button variant="outline" size="sm">2</Button>
                  <Button variant="outline" size="sm">3</Button>
                  <span>...</span>
                  <Button variant="outline" size="sm">10</Button>
                  <Button variant="outline" size="sm">Next</Button>
                </div>
              </div>
            </div>
            
            {/* Action Buttons */}
            <div className="mt-4 flex justify-center gap-2">
              <Button className="bg-blue-600 hover:bg-blue-700">Scrub Selected Claims</Button>
              <Button className="bg-blue-600 hover:bg-blue-700">Submit for Processing</Button>
              <Button className="bg-blue-600 hover:bg-blue-700">Push Claim Status to PMS</Button>
            </div>
          </TabsContent>
          
          <TabsContent value="by-claims">
            <Card>
              <CardContent className="p-4">
                <div className="text-center py-10">
                  <h3 className="text-lg font-medium">By Claims Content</h3>
                  <p className="text-gray-500">This tab will display claims sorted by claim number.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="by-insurance">
            <Card>
              <CardContent className="p-4">
                <div className="text-center py-10">
                  <h3 className="text-lg font-medium">By Insurance Content</h3>
                  <p className="text-gray-500">This tab will display claims sorted by insurance provider.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="by-practice-location">
            <Card>
              <CardContent className="p-4">
                <div className="text-center py-10">
                  <h3 className="text-lg font-medium">By Practice Location Content</h3>
                  <p className="text-gray-500">This tab will display claims sorted by practice location.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="by-provider">
            <Card>
              <CardContent className="p-4">
                <div className="text-center py-10">
                  <h3 className="text-lg font-medium">By Provider Content</h3>
                  <p className="text-gray-500">This tab will display claims sorted by healthcare provider.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="by-aging">
            <Card>
              <CardContent className="p-4">
                <div className="text-center py-10">
                  <h3 className="text-lg font-medium">By Aging Content</h3>
                  <p className="text-gray-500">This tab will display claims sorted by age.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ClaimSubmission;
