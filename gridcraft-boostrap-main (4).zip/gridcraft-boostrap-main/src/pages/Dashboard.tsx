
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MoreHorizontal, Info } from "lucide-react";
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend } from "recharts";
import { DateRange } from "react-day-picker";
import { DateRangePicker } from "@/components/DateRangePicker";
import { useState } from "react";
import { Button } from "@/components/ui/button";

const eligibilityData = [
  { id: 1, title: 'Total Appointments', value: 40, color: 'bg-blue-100 text-blue-600' },
  { id: 2, title: 'Verified Successfully', value: 40, color: 'bg-green-100 text-green-600' },
  { id: 3, title: 'Appointments Failed', value: 20, color: 'bg-red-100 text-red-600' },
  { id: 4, title: 'Policy Next Month', value: 10, color: 'bg-purple-100 text-purple-600' }
];

const paymentsData = [
  { name: 'Total EOBs downloaded', value: 85 },
  { name: 'EOBs Processed', value: 65 },
  { name: 'Payments Posted in PMS', value: 60 },
  { name: 'EOBs Pending to Post', value: 20 }
];

const arDenialsData = [
  { name: "Today's Rejections", value: 85 },
  { name: "Today's Denials", value: 65 },
  { name: 'Rejections resolved', value: 60 },
  { name: 'Denials Resolved', value: 20 },
  { name: "Today's Follow Up", value: 90 }
];

const claimsData = [
  { name: 'Claims Ready to File', value: 75, color: '#FFD166' },
  { name: 'Claims In Process', value: 125, color: '#F9A826' },
  { name: 'Claims Sent to Payers', value: 423, color: '#4D96FF' },
  { name: 'Pending Referrals', value: 12, color: '#9b87f5' },
];

const Dashboard = () => {
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: new Date(new Date().setDate(new Date().getDate() - 7)),
    to: new Date()
  });
  const [location, setLocation] = useState('');
  const [period, setPeriod] = useState('7d');

  return (
    <div className="p-6 max-w-full">
      <div className="mb-4">
        <h1 className="text-2xl font-bold">Welcome, Keplr Vision Group</h1>
      </div>

      {/* Filter Section */}
      <Card className="p-4 md:p-6 mb-6">
        <div className="flex flex-wrap gap-4 items-center justify-between">
          <div className="flex flex-wrap gap-4 items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Date Range:</p>
              <DateRangePicker 
                dateRange={dateRange}
                setDateRange={setDateRange}
              />
            </div>
            
            <div>
              <p className="text-sm text-gray-500 mb-1">Location:</p>
              <Select>
                <SelectTrigger className="w-40 bg-white">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Locations</SelectItem>
                  <SelectItem value="ny">New York</SelectItem>
                  <SelectItem value="la">Los Angeles</SelectItem>
                  <SelectItem value="ch">Chicago</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex flex-wrap items-center gap-2">
            <button className={`px-3 py-1 rounded-md text-sm ${period === 'today' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'}`} onClick={() => setPeriod('today')}>Today</button>
            <button className={`px-3 py-1 rounded-md text-sm ${period === 'yesterday' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'}`} onClick={() => setPeriod('yesterday')}>Yesterday</button>
            <button className={`px-3 py-1 rounded-md text-sm ${period === '7d' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'}`} onClick={() => setPeriod('7d')}>7 D</button>
            <button className={`px-3 py-1 rounded-md text-sm ${period === '30d' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'}`} onClick={() => setPeriod('30d')}>30 D</button>
            <button className={`px-3 py-1 rounded-md text-sm ${period === '3m' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'}`} onClick={() => setPeriod('3m')}>3 M</button>
            <button className={`px-3 py-1 rounded-md text-sm ${period === '6m' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'}`} onClick={() => setPeriod('6m')}>6 M</button>
            <button className={`px-3 py-1 rounded-md text-sm ${period === '12m' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'}`} onClick={() => setPeriod('12m')}>12 M</button>
          </div>
        </div>
      </Card>
      
      {/* Insurance Eligibility Overview & Payments Posting */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card className="p-4 md:p-6">
          <h2 className="text-lg font-semibold mb-4">Insurance Eligibility Overview</h2>
          <div className="grid grid-cols-2 gap-4">
            {eligibilityData.map((item) => (
              <div key={item.id} className={`${item.color} p-4 rounded-lg`}>
                <div className="text-3xl md:text-4xl font-bold">{item.value}</div>
                <div className="text-sm">{item.title}</div>
              </div>
            ))}
          </div>
        </Card>
        
        {/* Payments Posting */}
        <Card className="p-4 md:p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Payments Posting</h2>
            <div className="relative">
              <button className="p-1 hover:bg-gray-100 rounded">
                <MoreHorizontal size={18} />
              </button>
              <div className="absolute top-2 right-0 bg-gray-800 text-white text-xs py-1 px-2 rounded">
                72
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            {paymentsData.map((item, index) => (
              <div key={index} className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-sm">{item.name}</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-2 bg-blue-500 rounded-full" 
                    style={{ width: `${item.value}%` }}
                  />
                </div>
              </div>
            ))}
            
            <div className="flex justify-between mt-4">
              {[0, 25, 50, 75, 100].map((value) => (
                <span key={value} className="text-xs text-gray-500">{value}</span>
              ))}
            </div>
          </div>
        </Card>
      </div>
      
      {/* Claims Submission & AR/Denials */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Claims Submission */}
        <Card className="p-4 md:p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Claims Submission</h2>
            <Button variant="outline" size="sm">View Details</Button>
          </div>
          
          <div className="flex justify-center">
            <div className="w-56 h-56">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={claimsData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {claimsData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend layout="vertical" verticalAlign="middle" align="right" />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 mt-4 gap-2">
            {claimsData.map((item, index) => (
              <div key={index} className="flex flex-col items-center">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: item.color }} />
                  <span className="text-xs truncate">{item.name}</span>
                </div>
                <div className="font-semibold">{item.value}</div>
              </div>
            ))}
          </div>
        </Card>
        
        {/* AR/Denials Management */}
        <Card className="p-4 md:p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">AR/Denials Management</h2>
            <div className="relative">
              <button className="p-1 hover:bg-gray-100 rounded">
                <MoreHorizontal size={18} />
              </button>
              <div className="absolute top-2 right-0 bg-gray-800 text-white text-xs py-1 px-2 rounded">
                72
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            {arDenialsData.map((item, index) => (
              <div key={index} className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-sm">{item.name}</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-2 bg-blue-500 rounded-full" 
                    style={{ width: `${item.value}%` }}
                  />
                </div>
              </div>
            ))}
            
            <div className="flex justify-between mt-4">
              {[0, 25, 50, 75, 100].map((value) => (
                <span key={value} className="text-xs text-gray-500">{value}</span>
              ))}
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
