
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Dashboard from "./pages/Dashboard";
import StatusEnquiry from "./pages/StatusEnquiry";
import EligibilityOverview from "./pages/EligibilityOverview";
import ClaimSubmission from "./pages/ClaimSubmission";
import PaymentPosting from "./pages/PaymentPosting";
import ArDenials from "./pages/ArDenials";
import Settings from "./pages/Settings";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />}>
            <Route index element={<Dashboard />} />
            <Route path="/insurance-eligibility/status-enquiry" element={<StatusEnquiry />} />
            <Route path="/insurance-eligibility/overview" element={<EligibilityOverview />} />
            <Route path="/claim-submission" element={<ClaimSubmission />} />
            <Route path="/payment-posting" element={<PaymentPosting />} />
            <Route path="/ar-denials" element={<ArDenials />} />
            <Route path="/settings" element={<Settings />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
